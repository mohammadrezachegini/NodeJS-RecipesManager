const Application = require("./app/server")
// new Application(5000, "mongodb://127.0.0.1:27017/papuaCoffee")
new Application(3000, "mongodb+srv://reza:asdasd@serverlessinstance0.cyozwvh.mongodb.net/CSIS4495")